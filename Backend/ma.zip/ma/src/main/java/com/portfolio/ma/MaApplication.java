package com.portfolio.ma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MaApplication.class, args);
	}

}
